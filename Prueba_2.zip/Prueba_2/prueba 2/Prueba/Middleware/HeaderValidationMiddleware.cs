using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

public class HeaderValidationMiddleware
{
    private readonly RequestDelegate _next;

    public HeaderValidationMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var requiredHeaders = new[] { "UserId", "Nombre", "Paterno", "Materno" };

        foreach (var header in requiredHeaders)
        {
            if (!context.Request.Headers.ContainsKey(header))
            {
                context.Response.StatusCode = StatusCodes.Status400BadRequest;
                await context.Response.WriteAsync($"Falta el encabezado requerido: {header}");
                return;
            }
        }

        await _next(context);
    }
}
