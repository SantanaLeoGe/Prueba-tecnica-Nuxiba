using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Prueba.Models
{
    public class Empleado
    {
        [Key]
        public int UserId { get; set; }

        [Required]
        public double Sueldo { get; set; }

        [Required]
        public DateTime FechaIngreso { get; set; }

        [ForeignKey("UserId")]
        public Usuario Usuario { get; set; }
    }
}
