using System.ComponentModel.DataAnnotations;

namespace Prueba.Models
{
    public class Usuario
    {
        [Key]
        public int UserId { get; set; }

        public string Login { get; set; }
        public string Nombre { get; set; }
        public string Paterno { get; set; }
        public string Materno { get; set; }
        
        public ICollection<Empleado> Empleados { get; set; }
    }
}
