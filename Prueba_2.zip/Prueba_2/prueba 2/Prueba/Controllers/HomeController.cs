using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Prueba.Models;

namespace Prueba.Controllers;

public class HomeController : Controller
{
    
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult HeaderTest()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }

    public IActionResult Usuarios()
        {
            // Redirige a la página de usuarios (puedes redirigir a otra acción en el controlador de Usuarios)
            return RedirectToAction("Index", "Usuarios");
        }

        public IActionResult Empleados()
        {
            // Redirige a la página de empleados (puedes redirigir a otra acción en el controlador de Empleados)
            return RedirectToAction("Index", "Empleados");
        }
}
