using Microsoft.EntityFrameworkCore;
using Prueba.Models;

namespace Prueba.BaseDatos
{
    public class MiDbContext : DbContext
    {
        public MiDbContext(DbContextOptions<MiDbContext> options)
            : base(options)
        {
        }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Empleado> Empleados { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Empleado>()
                .HasKey(e => e.UserId); // Configura la clave primaria para Empleado

            modelBuilder.Entity<Usuario>()
                .HasKey(u => u.UserId); // Configura la clave primaria para Usuario

            modelBuilder.Entity<Empleado>()
                .HasOne(e => e.Usuario) // Configura la relación uno a uno
                .WithMany(u => u.Empleados)
                .HasForeignKey(e => e.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            base.OnModelCreating(modelBuilder);
        }
    }
}
